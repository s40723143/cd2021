%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gradient of the Vector of nonlinear equations w.r.t the design variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function[Phi] = Phi_matrix(x,q,n)

Phi = zeros(q,n);
E   = zeros(q,1);
F   = zeros(q,1);
dE  = zeros(q,n);
dF  = zeros(q,n);

theta_A = 0;
theta_B = pi/2;
delta_theta = (theta_B-theta_A)/(q-1);

[A,C,P,Q,AC,PQ] = rho_matrices(q,delta_theta);

r = rho_vector(x);
rd  = PQ*r;
rdd = AC*r;

for i = 1:q
    E(i) = (r(i)^2+2*rd(i)^2-r(i)*rdd(i));
    F(i) = (r(i)^2+rd(i)^2)^(3/2);    
    for j = 2:n+1
        if (i == j-1)
            dE(i,j-1) = 2*r(i)+4*rd(i)*PQ(i,j)-(rdd(i)+r(i)*AC(i,j));
            dF(i,j-1) = (3/2)*((r(i)^2+rd(i)^2)^(1/2))*(2*r(i)+2*rd(i)*PQ(i,j));
        else
            dE(i,j-1) = 4*rd(i)*PQ(i,j)-(r(i)*AC(i,j));
            dF(i,j-1) = (3/2)*((r(i)^2+rd(i)^2)^(1/2))*(2*rd(i)*PQ(i,j));
        end
        Phi(i,j-1) = (dE(i,j-1)*F(i)-E(i)*dF(i,j-1))/(F(i)^2);
    end    
end

