function[rho] = rho_vector(x)

% Initial parameters
d = 65*1e-3;
h = 83*1e-3;

rho_A = d/2;          % Rho values at P0
rho_B = h-rho_A;      % Rho values at Pn+1

rho = [rho_A;x;rho_B];