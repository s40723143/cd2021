%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ODA: Optimization package using the Orthogonal Decomposition Algorithm
% 
% This packages handles
%   1) Unconstrained linear problems (over- or determined)...LSSLS
%   2) 
%   3) 
%   4) Constrained Linear problems...........................LSSCLS
%   5) Constrained nonlinear problems........................LSSCNL
%   6) 
% 
% Jean-Fran�ois Gauthier, December 14, 2006
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
clear;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The user must specify:
%   1-
%   2-
%   3-
% 
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

q = 10;                     % Dimension of the function phi
n = q-2;                    % Number of design variables
l = 2;                      % Number of constraints

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Unconstrained linear problems (m>=n) (LSSLS) LSSLS initialisation param.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% ODA  = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Unconstrained linear problems (m<n) (MNSLS) initialisation parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% ODA  = 2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Unconstrained nonlinear problems (LSSNLS) initialisation parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% ODA  = 3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Constrained linear problems (LSSCLS) initialisation parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% ODA  = 4;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Constrained nonlinear problems (LSSCNL) initialisation parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ODA  = 5;
% ---------------------------- User Input ------------------------------ %
tolx  = 0.000000001;
tolh  = 0.000000001;
Max_i = 100;
% -------------------------- End User Input ---------------------------- %

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Arbitrary objective function (ARBITRARY) initialisation parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% ODA  = 6;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial guess (user input)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ---------------------------- User Input ------------------------------ %
x_i = zeros(q-2,1);
rho_i = rho_vector(x_i);
rho_A = rho_i(1);
rho_B = rho_i(q);

for j = 1:(q-2)
x_i(j) = rho_A + (rho_B-rho_A)*j/(q-1);
end

theta_A = 0;
theta_B = pi/2;
delta_theta = (theta_B-theta_A)/(q-1);

theta  = zeros(q,1);
theta(1) = theta_A;
theta(q) = theta_B;

for i = 2:1:(q-1)
    theta(i)    = theta(i-1)+delta_theta;
end
% -------------------------- End User Input ---------------------------- %

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Weighting matrix (user input)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ---------------------------- User Input ------------------------------ %
for i = 1:1:q
    for j = 1:1:q
        if (i == j)
            W(i,j) = 1/q;
        else
            W(i,j) = 0;
        end
    end
end
% -------------------------- End User Input ---------------------------- %

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ODA Package used (user input)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ---------------------------- User Input ------------------------------ %
% [u] = LSSLS(b,A,q,n,ODA)
% [x] = MNSLS()
% [x] = LSSNLS()
% [dx] = LSSCLS(b,A,W,d,C,q,n,ell,ODA)
[x,f_min] = LSSCNL(x_i,W,q,n,l,tolx,tolh,Max_i,ODA)
% [x] = ARBITRARY()
% -------------------------- End User Input ---------------------------- %

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Results display
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x_optimal = x;
rho_optimal = rho_vector(x_optimal);

% figure(100)
% polar(theta,rho_optimal)

d_theta = theta_A:(theta_B-theta_A)/((q-1)*10):theta_B;
sp = spline(theta,rho_optimal,d_theta);

figure(101)
polar(d_theta,sp)

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%