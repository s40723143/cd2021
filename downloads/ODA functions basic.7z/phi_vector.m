%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Vector of nonlinear equations (user defined function)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function[phi] = phi_vector(x,q,n)

phi = zeros(q,1);

theta_A = 0;
theta_B = pi/2;
delta_theta = (theta_B-theta_A)/(q-1);

[A,C,P,Q,AC,PQ] = rho_matrices(q,delta_theta);

r = rho_vector(x);
rd  = PQ*r;
rdd = AC*r;

for i = 1:q
    phi(i) = ((r(i))^2+2*(rd(i))^2-r(i)*rdd(i))/((r(i))^2+(rd(i))^2)^(3/2);
end