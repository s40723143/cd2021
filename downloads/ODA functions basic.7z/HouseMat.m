function H=HouseMat(v)

%Computes the reflection matrix associated to vector v.

m=length(v);

H=eye(m)-2*v*v'/(v'*v);