function[L,x0] = Lk_dx0(C,d,l,n)

CT = C';

[H,U] = Householder(CT);

E = [zeros(l,n-l);eye(n-l,n-l)];
L = H'*E;

% [U:0] is a nxp matrix, where p is the number of constraints, n the number of
% design variables. U is pxp and 0 is (n-p)xp.

UT = U';

% Now, we want to solve UT*y = d using foward substitution since UT is 
% lower-triangular:

sum = 0;
y = zeros(n,1);

for i = 1:l
    for j = 1:l
        if (i == j)
            y(i) = (d(i)-sum)/UT(i,j);
            sum = 0;
        elseif (i > j)
            for k = 1:j
                sum = sum + UT(i,j)*y(j);
            end
        end
    end
end

% Finally, x0 is equal to
x0 = (H')*y;

% H times its transpose is supposed to give the identity matrix
% WW = H*H';


