%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Vector of the constraints
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function[h] = h_vector(x,q,n,l)

h   = zeros(l,1);

theta_A = 0;
theta_B = pi/2;
delta_theta = (theta_B-theta_A)/(q-1);

[A,C,P,Q,AC,PQ] = rho_matrices(q,delta_theta);

r = rho_vector(x);
rdd = AC*r;

h(1) = rdd(1)-r(1);
h(2) = rdd(q)-r(q);