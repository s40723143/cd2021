%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gradient of constraints matrix J is a constant matrix (previously proved)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This function has to be define by the user
function[J] = J_matrix(x,q,n,l)

theta_A = 0;
theta_B = pi/2;
delta_theta = (theta_B-theta_A)/(q-1);

[A,C,P,Q,AC,PQ] = rho_matrices(q,delta_theta);

for i = 2:1:(q-1)
    J(1,i-1) = AC(1,i);                     % DHDX(1,:)
    J(2,i-1) = AC(q,i);                     % DHDX(2,:)
end