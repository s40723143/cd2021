function u=HouseVect(x)

%**************************************************************************
%This function computes the Householder vector of a non-zero norm vector.
%**************************************************************************

n=length(x);
u=zeros(n,1);
if x~=0
    u(1)=x(1)+sign(x(1))*norm(x);
else
    u(1)=norm(x);
end
u(2:n)=x(2:n);
