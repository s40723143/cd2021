%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of matrices A, C, P & Q in appendix of reference [1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function[A,C,P,Q,AC,PQ] = rho_matrices(npts,delta_theta)

A = zeros(npts,npts);
C = zeros(npts,npts);
P = zeros(npts,npts);
Q = zeros(npts,npts);

A_inv = zeros(npts,npts);
P_inv = zeros(npts,npts);

A(1,1) = 2;
A(npts,npts) = 2;

C(1,1) = -1;
C(npts,npts) = -1;

P(1,1) = 1/delta_theta;
P(npts,npts) = 1/delta_theta;

Q(1,1) = 0;
Q(npts,npts) = 0;

% tA = tB = infinity since gamma = pi/2 at P0 and Pn+1
for i = 1:1:(npts)
    for j = 1:1:(npts)
        if (i == j) && (i > 1 && i < npts)
            A(i,j) = 4;
            C(i,j) = -2;
            P(i,j) = 4;
            Q(i,j) = 0;
        elseif (i == j+1)
            A(i,j) = 1;
            C(i,j) = 1;
            P(i,j) = 1;
            Q(i,j) = -3;
        elseif (j == i+1)    
            A(i,j) = 1;
            C(i,j) = 1;
            P(i,j) = 1;
            Q(i,j) = 3; 
        end
    end
end

A = (delta_theta)*A;
C = (1/delta_theta)*C;

P(1,2) = 0;
P(npts,npts-1) = 0;

Q(1,2) = 0;
Q(npts,npts-1) = 0;

% Matrices A_inv and P_inv

A_inv = inv(A);
P_inv = inv(P);

AC = 6*A_inv*C;
PQ = P_inv*Q;


