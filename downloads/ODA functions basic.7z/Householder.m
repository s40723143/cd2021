function [H,U]=Householder(A)

%**************************************************************************
%This function uses the Householder method to decompose A (m by n, m>=n) into a
%reflection matrix H (m by m) and an upper triangular matrix U (m by n). 
%**************************************************************************

m=size(A,1);
n=size(A,2);
x=zeros(n,1);
Hi=zeros(m,m,n);
H=eye(m);
U=A;

for j=1:n
    v=zeros(m,1);
    Hi(:,:,j)=eye(m);
    v(j:m)=HouseVect(U(j:m,j));
    Hi(:,:,j)=HouseMat(v);
    U=Hi(:,:,j)*U;
    H=H*Hi(:,:,j)';
end
