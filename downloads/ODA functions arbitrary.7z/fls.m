function alpha = fls(xk,s,F,G,p1,p2)

% This m-file implements Fletcher's line search as described in
% Algorithm 7.4 of Dr. Antoniou's Notes "Optimization: Theory
% and Practice", and was written by John Wong, July 2001.
% Last modified: July 31, 2001.

% Usage: fls(x,s,F,G,p1,p2)
%    x:  Initial point
%    s:  Search direction
%    F:  Function to be minimized along the direction of s  
%    G:  Gradient of function F 
%    p1: Internal parameters that are required for the implementation of
%        the line search regardless of the application at hand.
%        It is a string (e.g. 'rho=.1') and can be a combination several
%        internal parameters (e.g., 'rho=.25;sigma=0.5').
%    p2: User-defined parameter vector. Note that p2 must be a VECTOR
%        with all components numerically specified. The order in which
%        the components of p2 appear must be the same as what they appear 
%        in function F and gradient G. For example, if p2 = [a b], then 
%        F.m and G.m must be in the form of
%        function z = F(x,p2)
%        and
%        function z = G(x,p2)
%    Useful p1's include:                                default value
%        'rho=   ' defines right bracket                      0.1
%        'sigma= ' defines left bracket  (sigma >= rho)       0.1
%        'tau= '   defines minimum step for sectioning        0.1
%        'gamma= '                                            0.75
%    Discussion on the line search algorithm and selection of suitable
%    values of the parameters in p1 can be found in Chapter 7, Sections
%    10 and 11 of the Lecture Notes.
%    Example 1: where non-default values for some internal parameters 
%               are specified:
%               alpha = fls(x,s,'myfun','mygrad','rho=0.25;sigma=0.5',[a b]);
%               where a and b are numerically specified parameters.
%    Example 2: where all internal parameters use their default values:
%               alpha = fls(x,s,'myfun','mygrad',[a b]);
%               where a and b are numerically specified parameters.
%    Example 3: where all internal parameters assume default values 
%               and no user defined parameters: 
%               alpha = fls(x,s,'myfun','mygrad');

k = 0;
m = 0;
tau = 0.1;      % Original value
gamma = 0.75;   % Original value
rho = 0.1;      % Original value
sigma = 0.1;    % Original value
mhat = 400;     
epsilon = 1e-10;
xk = xk(:);
s = s(:);
parameterstring ='';
% evaluate given parameters:
  if nargin > 4,
    if isstr(p1),
      eval([p1 ';']);
    else
      parameterstring = ',p1';
    end
  end
  if nargin > 5,
    if isstr(p2),
      eval([p2 ';']);
    else
      parameterstring = ',p2';
    end
  end
% compute f0 and g0
  eval(['f0 = ' F '(xk' parameterstring ');']);
  eval(['gk = ' G '(xk' parameterstring ');']);
  m = m+2;
  deltaf0 = f0;
% step 2 Initialize line search
  dk = s;
  aL = 0;
  aU = 1e99;
  fL = f0;
  dfL = gk'*dk;
  if abs(dfL) > epsilon,
    a0 = -2*deltaf0/dfL;
  else
    a0 = 1;
 end
 if ((a0 <= 1e-9)|(a0 > 1)),
    a0 = 1;
 end
%step 3
 while 1,
    deltak = a0*dk;
    eval(['f0 = ' F '(xk+deltak' parameterstring ');']);
    m = m + 1;
%step 4
    if ((f0 > (fL + rho*(a0 - aL)*dfL)) & (abs(fL - f0) > epsilon) & (m < mhat))
      if (a0 < aU)
        aU = a0;
      end
      % compute a0hat using equation 7.65
      a0hat = aL + ((a0 - aL)^2*dfL)/(2*(fL - f0 + (a0 - aL)*dfL));
      a0Lhat = aL + tau*(aU - aL);
      if (a0hat < a0Lhat)
        a0hat = a0Lhat;
      end
      a0Uhat = aU - tau*(aU - aL);
      if (a0hat > a0Uhat)
        a0hat = a0Uhat;
      end
      a0 = a0hat;
    else
      eval(['gtemp =' G '(xk+a0*dk' parameterstring ');']);
      df0 = gtemp'*dk;
      m = m + 1;
      % step 6
      if (((df0 < sigma*dfL) & (abs(fL - f0) > epsilon) & (m < mhat) & (dfL ~= df0)))
        deltaa0 = (a0 - aL)*df0/(dfL - df0);
        if (deltaa0 <= 0)
          a0hat = 2*a0;
        else
          a0hat = a0 + deltaa0;
        end
        a0Uhat = a0 + gamma*(aU - a0);
        if (a0hat > a0Uhat)
          a0hat = a0Uhat;
        end
        aL = a0;
        a0 = a0hat;
        fL = f0;
        dfL = df0;
      else
        break;
      end
    end
 end % while 1
%  if a0 < 1e-5,
%     alpha = 1e-5;
 if a0 < 1e-12,
    alpha = 1e-12;
 else
    alpha = a0;
 end 