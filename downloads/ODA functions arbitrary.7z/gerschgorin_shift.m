%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gerschgorin shift for the Hessian matrix of the objective function
% 
% Jean-Fran�ois Gauthier : 2007/06/21
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function mu = gerschgorin_shift(hessian)

m  = size(hessian,1);
n  = size(hessian,2);

if (m == n)
    for i = 1:m
        b = zeros(n);
        for j = 1:n
            if (j == i)
                a(i) = hessian(i,i);
            else
                b(j) = abs(hessian(i,j));
            end
        end
        r(i) = sum(b(1:n));
        l(i) = a(i)-r(i);
        u(i) = a(i)+r(i);
    end
    a = a;
    r = r;
    l = l;
    u = u;
    l_min = min(l);
    u_max = max(u);
    
    if (l_min < 0)
        
        deltak = u_max-l_min;
        mu = -(1+0.00001*deltak)*l_min;
    else
        mu = 0;
    end
    
elseif (m ~= n)
    fprintf('note : matrix must be square');
    mu = 0;
end