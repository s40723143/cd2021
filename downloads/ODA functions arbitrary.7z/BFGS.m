%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Broyden-Fletcher_Goldfarb-Shanno (BFGS) algorithm
% 
% Note : To use this file, the following files have to be modified with
%        respect to the problem at hand:
%           
%           -> fls_f.m      % function to be minimized
%           -> fls_gf.m     % gradient of the function to be minimized
% 
% by Jean-Fran�ois Gauthier : 2008/01/05
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function x_opt = BFGS(x,epsilon)

% i_x is used to visualize the steps of du throughout the FR algorithm
i_x(1,:) = x';

% The gradient for the initial guess
G = fls_gf(x);

% The initial Hessian-inverse
n = length(x);
B = eye(n);

% The search direction vector s is in the gradient opposit direction
s = -B*G;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialisation of parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

norm_G  = 1e10;
i       = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BFGS algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while (norm_G > epsilon)
    
    i = i+1;
    
    % Find the lambda that minimize f(x^(i+1))
    lambda = fls(x,s,'fls_f','fls_gf');
    
    d = lambda*s;
    x = x + d;
    
    i_x(i+1,:) = x';
    
    G_previous = G;
    G = fls_gf(x);    
    
    norm_G = norm(G);
    
    % BFGS method particularities
    g_i     = G - G_previous;
    alpha_i = 1 + (g_i'*B*g_i)/(d'*g_i);
    M       = alpha_i*(d*d')/(d'*g_i);
    N       = -(d*g_i'*B)/(d'*g_i);
    B       = B + M + N + N';
    
    % The direction for the next iteration is defined as:
    s = -B*G;
    
end

x_opt = x;
i_x;


