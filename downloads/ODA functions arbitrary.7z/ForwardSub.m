%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Forward Substitution of the linear system Lx = b, where
%
%   L is a (nxn) lower triangular matrix
%   b & x are n-dimensional vectors 
%
% by Jean-Francois Gauthier: 10/12/2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function x = ForwardSub(L,b)

n   = size(b,1);
sum = 0;

for i = 1:n
    for j = 1:n
        if (i==j)
            x(i,1) = (b(i)-sum)/L(i,j);
            sum = 0;
        elseif (i>j)
            sum = sum + L(i,j)*x(j);
        end
    end
end
