%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Isotropic orthogonal complement of J and the minimum norm solution dx0
% 
% Jean-Fran�ois Gauthier : 2008/01/05
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function[L,dx0] = ODA_L_dx0(J,g)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% where     J : gradient of the Constraints vector (pxn)
%           g : Constraints vector (px1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

p       = size(J,1);
n       = size(J,2);
n_prime = n-p;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Householder reflections used to render J' into upper-triangular form
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[H,U] = HH(J');  % U is a pxp upper-triangular matrix

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definition of the Isotropic orthogonal complement of J
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

E_U = zeros(p,n_prime);
E_L = eye(n_prime);
E   = [E_U;E_L];
L   = H'*E;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now, we want to solve the linear system U'*yu = -g -> forward sub.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

UT  = U';
sum = 0;
y   = zeros(n,1);   % y = [yu';yL'] where yu is px1 and yL is (n-p)x1

% Forward substitution, since UT is lower triangular
for i = 1:p
    for j = 1:p
        if (i == j)
            y(i) = (g(i)-sum)/UT(i,j);
            sum = 0;
        elseif (i > j)
            for k = 1:j
                sum = sum + UT(i,j)*y(j);
            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The minimum-norm solution dx0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dx0 = H'*y;



