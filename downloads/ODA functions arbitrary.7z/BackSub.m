%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Backward Substitution of the linear system Ux = b, where
%
%   U is a (nxn) upper triangular matrix
%   b & x are n-dimensional vectors 
%
% by Jean-Francois Gauthier: 10/12/2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function x = BackSub(U,b)

n   = size(b,1);
sum = 0;

for i = n:-1:1
    for j = n:-1:1
        if (i==j)
            x(i,1)=(b(i)-sum)/U(i,j);
            sum=0;
        elseif (i<j)
            sum = sum + U(i,j)*x(j);
        end
    end
end
