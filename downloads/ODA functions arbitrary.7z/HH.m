%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function uses the Householder reflections to decompose a rectangular
% matrix A (m by n, m>=n) into a reflection matrix H (m by m) and an
% upper-triangular matrix Ai (m by n)
%
% by Philippe Cardou
% modified by Jean-Fran�ois Gauthier : 2008/01/05
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [H,U,Ai] = HH(A)

m  = size(A,1);
n  = size(A,2);
Hi = zeros(m,m,n);
H  = eye(m);
Ai = A;             % This is the matrix that will be multiplied by the reflections
U  = zeros(n,n);

for k = 1:n
    
    v         = zeros(m,1);
    Hi(:,:,k) = eye(m);    
    v(k:m)    = HHVect(Ai(k:m,k));
    Hi(:,:,k) = HHMat(v);
    Ai        = Hi(:,:,k)*Ai;
    H         = Hi(:,:,k)*H;
    
end

for i = 1:n
    for j = 1:n
        U(i,j) = Ai(i,j);
    end
end
