%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fletcher-Reeves (FR) algorithm
%
% Note : To use this file, the following files have to be modified with
%        respect to the problem at hand:
%           
%           -> fls_f.m      % function to be minimized
%           -> fls_gf.m     % gradient of the function to be minimized
% 
% by Jean-Fran�ois Gauthier : 2008/01/05
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function x_opt = FR(x,epsilon)

% i_x is used to visualize the steps of du throughout the FR algorithm
i_x(1,:) = x';

% The gradient for the initial guess
G = fls_gf(x);

% The search direction vector s is in the gradient opposit direction
s = -G;        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialisation of parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

norm_G  = 1e10;
i       = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FR algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while (norm_G > epsilon)
    
    i = i+1;
    
    % Find the lambda that minimize f(x^(i+1))
    lambda = fls(x,s,'fls_f','fls_gf');
    
    x = x + lambda*s;
    
    i_x(i+1,:) = x';
    
    G_previous = G;
    G = fls_gf(x);
    
    norm_G = norm(G);
    norm_previous = norm(G_previous);
    
    % The direction direction for the next iteration is defined as:
    s = (-1)*G + ((norm_G)^2/(norm_previous)^2)*s;
    
end

x_opt = x;
i_x;
i




