%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gradient of the objective function w.r.t. du to be used in FR or BFGS
% methods
% 
% Note : To use this file, the following files have to be modified with
%        respect to the problem at hand:
%           
%           -> ODA_g.m
%           -> ODA_J.m
%           -> ODA_gf.m
% 
% by Jean-Fran�ois Gauthier : 2008/01/05
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function gf_du = fls_gf(du)

load designV;                   % x       @ iteration k
     
g       = ODA_g(x);             % g       @ iteration k
J       = ODA_J(x);             % J       @ iteration k
[L,dx0] = ODA_L_dx0(J,-g);      % L & dx0 @ iteration k

x       = x + dx0 + L*du;       % x       @ iteration k+1

G       = ODA_gf(x);
gf_du   = L'*G;